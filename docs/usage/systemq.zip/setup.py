from setuptools import find_packages, setup

with open('requirements.txt', encoding='utf-8') as f:
    requirements = f.read()


setup(
    name="systemq",
    version='6.0.1',
    author="baqis",
    author_email="baqis@baqis.ac.cn",
    url="https://gitee.com/",
    license="MIT",
    keywords="quantum lab",
    description="control, measure and visualization",
    long_description='long_description',
    long_description_content_type='text/markdown',
    packages=find_packages(exclude=['dev*', 'home*', 'lib*', 'src*']),
    package_data={"": ["*.pyd", "*.so"]},
    include_package_data=True,
    install_requires=requirements,
    python_requires='>=3.10.0',
    classifiers=[
        'Development Status :: 5 - Stable',
        'Intended Audience :: Developers',
        'Intended Audience :: Science/Research',
        'License :: OSI Approved :: MIT',
        'Natural Language :: Chinese (Simplified)',
        'Natural Language :: English',
        'Operating System :: Microsoft :: Windows',
        'Operating System :: POSIX :: Linux',
        'Operating System :: MacOS :: MacOS X',
        'Programming Language :: Python :: 3.10',
        'Topic :: Scientific/Engineering :: Physics',
    ],
    project_urls={
        'source': 'https://gitee.com',
    },
)
