from qlispc import Architecture

from ..config import QuarkConfig, QuarkLocalConfig
from .code import assembly_code
from .data import assembly_data

rcpArchitecture = Architecture('rcp', "", assembly_code, assembly_data,
                                  QuarkConfig, QuarkLocalConfig)
