from qlispc import register_arch

from .baqis import baqisArchitecture
from .baqis2 import baqis2Architecture

register_arch(baqis2Architecture)
