from qlispc.arch.baqis.config import QuarkConfig, QuarkLocalConfig
