# -*- coding: utf-8 -*-
"""
    pyvisa.thirdparty
    ~~~~~~~~~~~~~~~~~

    Third party libraries and modules bundled with PyVISA.

    This file is part of PyVISA.

    :copyright: 2014 by PyVISA Authors, see AUTHORS for more details.
    :license: MIT, see LICENSE for more details.
"""
