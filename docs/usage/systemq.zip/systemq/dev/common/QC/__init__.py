from .lib import DeviceInterface
from .lib import all_ip